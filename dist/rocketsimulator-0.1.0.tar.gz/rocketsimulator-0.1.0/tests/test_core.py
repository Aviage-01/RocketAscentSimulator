""""Unit tests for the rocket simulator core functionality."""

import numpy as np
import pytest
from rocketSimulator import RocketStage, RocketAscentSimulator

def test_rocket_stage_initialization():
    """Test that a RocketStage can be initialized with the correct attributes."""
    def thrust_func(t, state):
        return 1000.0
    
    def isp_func(t, state):
        return 300.0
    
    def criteria_func(t, state):
        return 1.0
    
    def drag_func(alpha, mach):
        return 0.1
    
    stage = RocketStage(
        dry_mass=1000.0,
        propellant_mass=9000.0,
        thrust=thrust_func,
        isp=isp_func,
        stage_criteria=criteria_func,
        drag_coeff=drag_func,
        lift_coeff=drag_func,  # Same function for simplicity
        reference_area=1.0
    )
    
    assert stage.dry_mass == 1000.0
    assert stage.propellant_mass == 9000.0
    assert stage.thrust(0, None) == 1000.0
    assert stage.isp(0, None) == 300.0
    assert stage.stage_criteria(0, None) == 1.0
    assert stage.drag_coeff(0, 0) == 0.1
    assert stage.reference_area == 1.0

def test_simulator_initialization():
    """Test that the simulator can be initialized with stages."""
    def dummy_func(*args):
        return 1.0
    
    stage = RocketStage(
        dry_mass=1000.0,
        propellant_mass=9000.0,
        thrust=dummy_func,
        isp=dummy_func,
        stage_criteria=dummy_func,
        drag_coeff=dummy_func,
        lift_coeff=dummy_func,
        reference_area=1.0
    )
    
    def ascent_profile(t, state):
        return np.pi/4, 1.0  # 45° pitch, full throttle
    
    simulator = RocketAscentSimulator([stage], ascent_profile)
    
    assert len(simulator.stages) == 1
    assert simulator._current_stage == 0
    assert simulator._current_stage_start_time == 0.0

def test_gravity_calculation():
    """Test that gravity is calculated correctly at different altitudes."""
    from rocketSimulator.core import RocketAscentSimulator
    
    # Create a dummy simulator with no stages (we won't actually run it)
    simulator = RocketAscentSimulator([], lambda t, s: (0, 0))
    
    # Test at sea level
    g_sea = simulator._gravity(0)
    assert np.isclose(g_sea, 9.8, rtol=0.1)  # Should be close to 9.8 m/s²
    
    # Test at 100km altitude
    g_100km = simulator._gravity(100000)  # 100 km
    assert g_100km < g_sea  # Should be less than sea level
    assert np.isclose(g_100km, 9.5, rtol=0.1)  # Should be about 9.5 m/s² at 100km


def test_falcon9_ascent():
    """Test a Falcon 9-like rocket ascent for reasonable final values."""

    # Constants
    R_EARTH = 6.371e6  # m
    g0 = 9.80665       # m/s²

    # Stage thrust/ISP depending on pressure
    def thrust_func(t, state):
        x, y = state[0], state[1]
        alt = np.sqrt(x**2 + y**2) - R_EARTH
        _, p = simulator._atmosphere_model(alt)

        # Falcon 9 first stage rough values
        T_vac = 7.6e6  # N
        T_sl = 7.6e6 * 0.9  # sea level reduction ~10%
        thrust = T_vac + (T_sl - T_vac) * (p / 101325)
        return thrust

    def isp_func(t, state):
        x, y = state[0], state[1]
        alt = np.sqrt(x**2 + y**2) - R_EARTH
        _, p = simulator._atmosphere_model(alt)

        Isp_vac = 340  # s
        Isp_sl = 311   # s
        isp = Isp_vac + (Isp_sl - Isp_vac) * (p / 101325)
        return isp

    def stage_criteria(t, state):
        # Burn until propellant depleted
        return 1.0

    def drag_coeff(state):
        return 0.3  # rough value for slender rocket

    # Falcon 9 first stage
    stage1 = RocketStage(
        dry_mass=25600,
        propellant_mass=395700,
        thrust=thrust_func,
        isp=isp_func,
        stage_criteria=stage_criteria,
        drag_coeff=drag_coeff,
        lift_coeff=lambda state: 0.0,
        reference_area=10.0  # m²
    )

    # Ascent profile: pitch program, 90° vertical then gravity turn
    def ascent_profile(t, state):
        # Simple linear gravity turn to 80° pitch by 30 km
        x, y = state[0], state[1]
        alt = np.sqrt(x**2 + y**2) - R_EARTH
        if alt < 1000:
            pitch = np.pi / 2  # vertical
        elif alt < 30000:
            pitch = np.pi/2 - (alt - 1000) / (30000-1000) * (np.pi/2 - np.radians(80))
        else:
            pitch = np.radians(80)
        return pitch, 1.0  # full throttle

    global simulator  # Needed for thrust/ISP access
    simulator = RocketAscentSimulator([stage1], ascent_profile)

    # Simulate
    results = simulator.simulate(t_span=(0, 180), max_step=1.0)

    # Check final altitude and velocity are reasonable
    final_y = results.y[1, -1] - R_EARTH
    final_v = np.sqrt(results.y[2, -1]**2 + results.y[3, -1]**2)

    assert final_y > 50000  # >50 km
    assert final_v > 1500    # m/s



# Add more tests as needed
test_rocket_stage_initialization()
test_simulator_initialization()
test_gravity_calculation()
test_falcon9_ascent()