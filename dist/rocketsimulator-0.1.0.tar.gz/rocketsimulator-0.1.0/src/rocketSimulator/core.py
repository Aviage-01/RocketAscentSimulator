# Licensed under the PolyForm Noncommercial License 1.0.0
"""Core simulation logic for the rocket ascent simulator."""

from typing import Callable, Dict, List, Optional, Tuple, Union
import numpy as np
from scipy.integrate import solve_ivp

try:
    from models import *

except:
    from . import *

class RocketAscentSimulator:
    """
    Simulates the ascent of a multi-stage rocket through Earth's atmosphere.
    """

    def __init__(self, stages: List[RocketStage], ascent_profile: Callable[[float, np.ndarray], np.ndarray]):
        """
        Initialize the rocket simulator.

        Args:
            stages: List of RocketStage objects in ascending order (first to fire first)
            ascent_profile: Function returning (pitch, throttle) for given time and state
        """
        self.stages = stages
        self.ascent_profile = ascent_profile
        self._current_stage = 0
        self._current_stage_start_time = 0.0

    def _atmosphere_model(self, altitude: Union[float, int, np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Simple exponential atmosphere model.

        Args:
            altitude: Altitude above sea level (m). Can be float/int or np.ndarray.

        Returns:
            Tuple of (density in kg/m^3, pressure in Pa)
        """
        altitude = np.atleast_1d(altitude)  # ensure array for vectorised ops

        T = np.empty_like(altitude, dtype=float)
        p = np.empty_like(altitude, dtype=float)

        # Upper atmosphere
        mask = altitude > 25000
        T[mask] = -131.21 + 0.00299 * altitude[mask]
        p[mask] = 2.488 * ((T[mask] + 273.1) / 216.6) ** (-11.388)

        # Lower stratosphere
        mask = (altitude > 11000) & (altitude <= 25000)
        T[mask] = -56.46
        p[mask] = 22.65 * np.exp(1.73 - 0.000157 * altitude[mask])

        # Troposphere
        mask = altitude <= 11000
        T[mask] = 15.04 - 0.00649 * altitude[mask]
        p[mask] = 101.29 * ((T[mask] + 273.1) / 288.08) ** 5.256

        rho = p / (0.2869 * (T + 273.1))  # Density in kg/m^3
        p = p * 1000  # Convert pressure to Pa

        # Return scalar if input was scalar
        if np.ndim(altitude) == 0 or altitude.shape == ():
            return float(rho[0]), float(p[0])
        return rho, p

    def _gravity(self, altitude: float) -> float:
        """Calculate gravitational acceleration at given altitude."""
        return G * M_earth / (R_earth + altitude) ** 2

    def _get_thrust_and_mass_flow(self, t: float, state: np.ndarray, stage_num=None, thrust_only=False) -> Tuple[
        float, float]:
        """
        Get current thrust and mass flow rate.

        Args:
            t: Current time (s)
            state: Current state vector [x, y, vx, vy, m]

        Returns:
            Tuple of (thrust in N, mass flow rate in kg/s)
        """

        stage_num = self._current_stage if stage_num == None else stage_num

        if stage_num >= len(self.stages):
            return np.array([0.0, 0.0])

        x, y, vx, vy, m = state
        stage = self.stages[stage_num]

        # Sum the masses of all upper stages (dry + propellant)
        upper_stages_mass = sum([s.dry_mass + s.propellant_mass for s in self.stages[stage_num + 1:]])

        # Current stage propellant = total mass - upper stages - current stage dry mass
        stage_current_prop = m - upper_stages_mass - stage.dry_mass

        stage_current_prop = np.maximum(stage_current_prop, 0.0)

        # Calculate thrust and mass flow rate
        pitch, throttle = self.ascent_profile(t, state)
        current_thrust = throttle * stage.thrust(t - self._current_stage_start_time, state)
        current_isp = stage.isp(t - self._current_stage_start_time, state)
        mass_flow = current_thrust / (current_isp * g0) if current_isp > 0 else 0.0

        # Check if we've run out of propellant
        current_thrust = np.where(stage_current_prop <= 0, 0.0, current_thrust)
        mass_flow = np.where(stage_current_prop <= 0, 0.0, mass_flow)

        if thrust_only:
            return current_thrust

        return np.array([current_thrust, mass_flow])

    def _get_drag(self, state: np.ndarray, stage_num=None) -> float:
        """
        Calculate drag force.

        Args:
            state: Current state vector [x, y, vx, vy, m]

        Returns:
            Drag force in N
        """
        vx, vy = state[2], state[3]
        v = np.sqrt(vx ** 2 + vy ** 2)
        altitude = np.sqrt(state[0] ** 2 + state[1] ** 2) - R_earth
        rho, _ = self._atmosphere_model(altitude)

        if stage_num is None:
            stage_num = self._current_stage

        vx_arr = np.atleast_1d(vx)
        vy_arr = np.atleast_1d(vy)
        v_arr = np.atleast_1d(v)
        rho_arr = np.atleast_1d(rho)
        stage_num_arr = np.atleast_1d(stage_num)

        drag_force = np.zeros_like(v_arr, dtype=float)
        lift_force = np.zeros_like(v_arr, dtype=float)

        for sn in np.unique(stage_num_arr):
            mask = stage_num_arr == sn
            stage = self.stages[sn]
            drag_force[mask] = 0.5 * rho_arr[mask] * v_arr[mask] ** 2 * stage.drag_coeff(state) * stage.reference_area
            lift_force[mask] = 0.5 * rho_arr[mask] * v_arr[mask] ** 2 * stage.lift_coeff(state) * stage.reference_area

        # initialise drag_vector array
        drag_vector = np.zeros((len(vx_arr), 2))

        # Only apply where velocity is non-zero
        nonzero_mask = v_arr > 0
        vel_unit = np.zeros((len(v_arr), 2))  # 2D array for x and y components
        vel_unit[nonzero_mask] = np.stack([vx_arr, vy_arr], axis=1)[nonzero_mask] / v_arr[nonzero_mask, None]

        # Drag along velocity
        drag_vector[nonzero_mask] = -drag_force[nonzero_mask, None] * vel_unit[nonzero_mask]

        # Lift perpendicular (+90° rotation: [-vy, vx])
        lift_vector = np.zeros_like(drag_vector)
        lift_vector[nonzero_mask] = lift_force[nonzero_mask, None] * np.stack([-vy_arr, vx_arr], axis=1)[nonzero_mask] / \
                                    v_arr[nonzero_mask, None]

        # Total aerodynamic vector
        drag_vector += lift_vector

        # If original vx, vy were scalars, return 1x2 array
        if np.isscalar(vx) and np.isscalar(vy):
            drag_vector = drag_vector[0]

        return drag_vector

    def _equations_of_motion(self, t: float, state: np.ndarray) -> np.ndarray:
        """
        Calculate time derivatives of the state vector.

        State vector: [x, y, vx, vy, m]
        Derivatives: [dx/dt, dy/dt, dvx/dt, dvy/dt, dm/dt]
        """
        x, y, vx, vy, m = state
        r = np.array([x, y])
        r_mag = np.linalg.norm(r)
        altitude = r_mag - R_earth

        # Unit vectors
        radial_unit = r / r_mag  # points away from Earth's centre
        tangent_unit = np.array([-radial_unit[1], radial_unit[0]])  # 90° CCW from radial

        # Get pitch and throttle from ascent profile
        pitch, throttle = self.ascent_profile(t, state)

        # Convert pitch relative to tangent into Cartesian coordinates
        thrust_dir = -np.cos(pitch) * tangent_unit + np.sin(pitch) * radial_unit

        # Get thrust and mass flow rate
        thrust, m_dot = self._get_thrust_and_mass_flow(t, state)

        # Calculate gravity
        g = self._gravity(altitude)
        g_vector = -g * radial_unit

        drag_vector = self._get_drag(state)  # modify _get_drag to accept arrays if needed

        # Total acceleration
        a = (thrust * thrust_dir + drag_vector) / m + g_vector

        vx = np.atleast_1d(vx)[0]
        vy = np.atleast_1d(vy)[0]
        ax = np.atleast_1d(a[0])[0]
        ay = np.atleast_1d(a[1])[0]
        m_dot_val = np.atleast_1d(m_dot)[0] #This is an awful solution but it works

        dstate_dt = np.array([vx, vy, a[0], a[1], -m_dot])

        return dstate_dt

    def simulate(self, t_span: Tuple[float, float],
                 max_step: float = 1.0, **solver_kwargs) -> Dict:
        """
        Simulate the rocket's ascent.

        Args:
            t_span: Time span for simulation (start, end) in seconds
            max_step: Maximum step size for the solver (s)
            **solver_kwargs: Additional arguments to pass to solve_ivp

        Returns:
            Dictionary containing simulation results
        """

        self._current_stage = 0
        self._current_stage_start_time = 0.0

        t0, tf = t_span
        times = []
        states = []
        stage_numbers = []

        initial_state = np.array([
            0.0,  # x (m)
            R_earth,  # y (m), starting at Earth's surface
            0.0,  # vx (m/s)
            0.0,  # vy (m/s)
            sum([stage.dry_mass + stage.propellant_mass for stage in self.stages])  # Initial mass (kg)
        ])

        current_y0 = initial_state
        current_t0 = t0

        # Define event functions
        def crash_event(t, y):
            x, y_pos, vx, vy, m = y
            r = np.sqrt(x ** 2 + y_pos ** 2)
            altitude = r - R_earth
            return altitude

        crash_event.terminal = True
        crash_event.direction = -1

        while current_t0 < tf:
            stage_sep_event = self.stages[self._current_stage].stage_criteria
            stage_sep_event.terminal = True

            sol = solve_ivp(
                self._equations_of_motion,
                (current_t0, tf),
                current_y0,
                method='DOP853',
                max_step=max_step,
                events=[stage_sep_event, crash_event],
                **solver_kwargs
            )

            # Append results
            times.append(sol.t)
            states.append(sol.y)
            stage_numbers.append(np.full(sol.t.shape, self._current_stage))

            # Check which event triggered
            stage_triggered = len(sol.t_events[0]) > 0
            crash_triggered = len(sol.t_events[1]) > 0

            if crash_triggered:
                # Stop simulation completely
                break

            elif stage_triggered:
                # Increment stage and restart
                self._current_stage += 1
                self._current_stage_start_time = sol.t[-1]
                current_y0 = sol.y[:, -1]
                current_y0[4] = sum(
                    [stage.dry_mass + stage.propellant_mass for stage in self.stages[self._current_stage:]])
                current_t0 = sol.t[-1]

            else:
                # No events; normal completion
                break

        # Concatenate results
        times = np.concatenate(times)
        states = np.hstack(states)
        stage_numbers = np.concatenate(stage_numbers)

        results = {
            't': times,
            'x': states[0],
            'y': states[1],
            'vx': states[2],
            'vy': states[3],
            'm': states[4],
            'stage': stage_numbers,
            'rocket': self,
            'success': True,
            'message': 'Simulation completed'
        }

        # Calculate additional quantities
        r = np.sqrt(results['x'] ** 2 + results['y'] ** 2)
        v = np.sqrt(results['vx'] ** 2 + results['vy'] ** 2)
        altitude = r - R_earth

        # Angle of position vector relative to +x axis
        theta = np.arctan2(results['y'], results['x'])

        # Starting angle (launch point: x=0, y=R_earth)
        theta0 = np.arctan2(R_earth, 0)  # = pi/2
        angular_displacement = theta - theta0

        # Unwrap to keep it continuous
        angular_displacement = np.unwrap(angular_displacement)

        # Arc length = angular displacement * planet radius
        horizontal_distance = R_earth * angular_displacement

        # Flight path angle relative to local horizontal (tangent at r)
        flight_path_angle = np.arctan2(results['vx'] * results['y'] - results['vy'] * results['x'],
                                       results['vx'] * results['x'] + results['vy'] * results['y'])

        results.update({
            'altitude': altitude,
            'velocity': v,
            'horizontal_distance': horizontal_distance,
            'flight_path_angle': flight_path_angle,
        })

        return results
